import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Select from 'react-dropdown-select';
import {base_url} from '../Globals';
import { CardData, GlobalData, BundleType, ProtocolType } from '../types';
import { 
    ThemeProvider, 
    CSSReset, 
    IconButton, 
    Button, 
    Box, 
    FormControl, 
    InputGroup, 
    Image, 
    Text, 
    Heading, 
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    useDisclosure,
} from '@chakra-ui/react'
import { TriangleDownIcon, EditIcon, AddIcon } from '@chakra-ui/icons'
import { Link as RouteLink } from 'react-router-dom'
import theme from '../styles/theme'

type FileUploadProps = {
    onChange: (event: any) => void
    accept: string
    buttonText: string
}
  
const FileUpload = (props: FileUploadProps) => {
    const { accept, onChange, buttonText } = props
    
    const inputRef = useRef<HTMLInputElement>(null)

    const handleClick = (event: any) => {
        inputRef?.current?.click()
        event.stopPropagation()
    }

    const onChangeWrapper = (event: any) => {
        onChange(event)
        event.stopPropagation()
    }
    return (
        <InputGroup onClick={handleClick}>
          <input
            accept={accept}
            type={'file'}
            multiple={false}
            hidden
            onChange={onChangeWrapper}
            ref={inputRef}
          />
          <Button onClick={handleClick}>
            {buttonText}
          </Button>
        </InputGroup>
    )
}

  
type HeaderProps = {
    data: CardData[], 
    bundles: BundleType[], 
    protocols: ProtocolType[], 
    selBundle: BundleType|undefined, 
    selProtocol: ProtocolType|undefined, 
    onLoad: Function, 
    onOpenSave: Function, 
    onEditSave: Function, 
    onCreateSave: Function
}

const Header = (props: HeaderProps) => {
    const navigate = useNavigate();

    const { bundles, protocols, selBundle, selProtocol } = props;
    const { 
        isOpen: isEditOpen, 
        onOpen: onEditOpen, 
        onClose: onEditClose
    } = useDisclosure();
    const { 
        isOpen: isOpenOpen, 
        onOpen: onOpenOpen, 
        onClose: onOpenClose
    } = useDisclosure();
    const { 
        isOpen: isCreateOpen, 
        onOpen: onCreateOpen, 
        onClose: onCreateClose
    } = useDisclosure();
    const {
        isOpen: isPreviewOpen, 
        onOpen: onPreviewOpen, 
        onClose: onPreviewClose
    } = useDisclosure();

    const [bundleName, setBundleName] = useState<string>('');
    const [protocolName, setProtocolName] = useState<string>('');
    const [isOpenNewBundle, setIsOpenNewBundle] = useState<boolean>(false);
    const [title, setTitle] = useState<string>('');
    const [subTitle, setSubTitle] = useState<string>('');
    const [rightCards, setRightCards] = useState<CardData[]>([]);
    const [selectedBundleForOpen, setSelectedBundleForOpen] = useState<BundleType>();
    const [selectedBundle, setSelectedBundle] = useState<BundleType>();
    const [selectedProtocol, setSelectedProtocol] = useState<ProtocolType>();
    const [selectableProtocols, setSelectableProtocols] = useState<ProtocolType[]>([]);

    const DownloadJSON = (Data: any) => {
        const savingData: GlobalData = {
            properties: {
                bundle: selBundle ? selBundle : bundles[0], 
                protocol: selProtocol ? selProtocol : protocols[0]
            }, 
            blocks: Data
        }
        const dataStr =
            'data:application/json;charset=utf-8,' + 
            encodeURIComponent(JSON.stringify(savingData));
        const download = document.createElement('a');
        download.setAttribute('href', dataStr);
        download.setAttribute('download', 'CardData' + '.json');
        document.body.appendChild(download);
        download.click();
        download.remove();
    };

    const handleFileInput = (event: any) => {
        var fileToLoad = event.target.files[0];
        var fileReader = new FileReader();
        fileReader.onload = function(fileLoadedEvent) {
            const textFromFileLoaded = fileLoadedEvent.target?fileLoadedEvent.target.result:'';
            const tempData = JSON.parse(textFromFileLoaded as string);
            setRightCards(tempData.blocks);
            props.onLoad(tempData);
        };
        fileReader.readAsText(fileToLoad, 'UTF-8');
    }

    const openNewBundle = () => {
        setIsOpenNewBundle(!isOpenNewBundle);
    }
    
    const onClickOpen = () => {
        onOpenClose();
        if (selectedProtocol) {
            const targetUrl = `/builder/${selectedProtocol.id}`;
            navigate(targetUrl);
            props.onOpenSave(selectedBundleForOpen, selectedProtocol);
        }
    }

    const onClickSave = () => {
        onEditClose();
        if (selectedBundle && selectedProtocol) {
            if (selectedBundle.fields.protocols.includes(selectedProtocol.id)) {
                return;
            }
            props.onEditSave(selectedBundle, selectedProtocol);
        }
    }

    const onClickCreate = () => {
        onCreateClose();
        if (isOpenNewBundle) {
            if (bundleName === '' || protocolName === '') return;
            props.onCreateSave(selectedBundle, bundleName, protocolName, isOpenNewBundle);
            setBundleName('');
            setProtocolName('');
            setIsOpenNewBundle(false);
        } else if (selectedBundle && protocolName !== '') {
            if (!selectedBundle || protocolName === '') return;
            props.onCreateSave(selectedBundle, bundleName, protocolName, isOpenNewBundle);
            setBundleName('');
            setProtocolName('');
            setIsOpenNewBundle(false);
        }
    }

    const changeSelectedBundleForOpen = (value: BundleType) => {
        setSelectedBundleForOpen(value);
        const tempProtocols = protocols.filter((protocol) => protocol.fields.bundles.includes(value.id));
        setSelectableProtocols(tempProtocols);
    }

    useEffect(() => {
        setRightCards(props.data);
    }, [props]);

    useEffect(() => {
        setTitle(selBundle ? selBundle.fields.name : bundles[0]?.fields?.name);
        setSubTitle(selProtocol ? selProtocol.fields.name : protocols[0]?.fields?.name);
        setSelectedBundle(selBundle);
        setSelectedProtocol(selProtocol);
    }, [protocols, selProtocol, bundles, selBundle]);

    return (
        <ThemeProvider theme={theme}>
            <CSSReset />
            <Box display="flex" height="76px" pt="16px" pb="16px" borderBottom="1px solid lightgray">
                <Box w="325px" display="flex" align="flex-start">
                    <Image src={`${base_url}/assets/logo_small.png`} width="40px" height="37px" mt="2px" alt="Logo"/>
                    <Heading as="h1" size="lg" ml="4">Protocol Editor</Heading>
                </Box>
                <Box id="details" w="500px" display="flex">
                    <Box mr="4">
                        <Heading as="h3" size="sm">{title}</Heading>
                        <Text>{subTitle}</Text>
                    </Box>            
                    <IconButton
                        aria-label=""
                        icon={<TriangleDownIcon />}
                        onClick={onOpenOpen}
                    >
                    </IconButton>
                    <IconButton
                        aria-label=""
                        icon={<EditIcon />}
                        onClick={onEditOpen}
                        style={{marginLeft: '5px'}}
                    >
                    </IconButton>
                    <IconButton
                        aria-label=""
                        icon={<AddIcon />}
                        onClick={onCreateOpen}
                        style={{marginLeft: '5px'}}
                    >
                    </IconButton>
                </Box>
                <Box w="350px" display="flex" float="right">
                    <Box ml="4">
                        <Button
                            aria-label="delete"
                            onClick={() => {
                                DownloadJSON(rightCards);
                            }}
                            >
                            Save JSON
                        </Button>
                    </Box>
                    <Box ml="4">
                        <FormControl>
                        <FileUpload
                            accept={'.json'}
                            onChange={handleFileInput}
                            buttonText="Load JSON"
                        />
                        </FormControl>
                    </Box>
                    <Box position="absolute" right="100">
                        {
                            (selBundle && selProtocol && selBundle.id && selProtocol.id) && (
                                // <a href={`/bundles/${selBundle!.id}/protocols/${selProtocol!.id}`}>
                                    <Button colorScheme="blue" onClick={onPreviewOpen}>
                                        Preview
                                    </Button>
                                // </a>
                            )
                        }
                    </Box>
                </Box>
            </Box>
            <Modal closeOnOverlayClick={false} isOpen={isOpenOpen} onClose={onOpenClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader mt="8">Open existing protocol</ModalHeader>
                    <ModalBody pb={8} align="left">
                        <div style={{margin: '10px 0px'}}>
                            <span className="inputlabel">Bundle: </span>
                            {
                                (bundles.length > 0) && (
                                    <Select
                                        className="addbranch"
                                        options={bundles}
                                        values={selectedBundleForOpen ? [selectedBundleForOpen] : []}
                                        onChange={(value) => {
                                            changeSelectedBundleForOpen(value[0]);
                                        }}
                                        labelField="fields.name"
                                        valueField="id"
                                    />
                                )
                            }
                        </div>
                        <div style={{margin: '10px 0px'}}>
                            <span className="inputlabel">Protocol: </span>
                            {
                                <Select
                                    className="addbranch"
                                    options={selectableProtocols}
                                    values={selectedProtocol ? [selectedProtocol] : []}
                                    onChange={(value) => {
                                        setSelectedProtocol(value[0]);
                                    }}
                                    labelField="fields.name"
                                    valueField="id"
                                />
                            }
                        </div>
                        <Box display="flex" float="right" mt="4">
                            <Button colorScheme="gray" onClick={onOpenClose}>Cancel</Button>
                            <Button colorScheme="blue" ml="4" onClick={onClickOpen}>Open</Button>
                        </Box>
                    </ModalBody>
                </ModalContent>
            </Modal>
            <Modal closeOnOverlayClick={false} isOpen={isEditOpen} onClose={onEditClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader mt="8">Edit current protocol</ModalHeader>
                    <ModalBody pb={8} align="left">
                        <div style={{margin: '10px 0px'}}>
                            <span className="inputlabel">Bundle: </span>
                            {
                                (bundles.length > 0) && (
                                    <Select
                                        className="addbranch"
                                        options={bundles}
                                        values={selectedBundle ? [selectedBundle] : [bundles[0]]}
                                        onChange={(value) => {
                                            setSelectedBundle(value[0]);
                                        }}
                                        labelField="fields.name"
                                        valueField="id"
                                    />
                                )
                            }
                        </div>
                        <div style={{margin: '10px 0px'}}>
                            <span className="inputlabel">Protocol: </span>
                            <p className="globalinput">{selectedProtocol?.fields.name}</p>
                        </div>
                        <Box display="flex" float="right" mt="4">
                            <Button colorScheme="gray" onClick={onEditClose}>Cancel</Button>
                            <Button colorScheme="blue" ml="4" onClick={onClickSave}>Save</Button>
                        </Box>
                    </ModalBody>
                </ModalContent>
            </Modal>
            <Modal closeOnOverlayClick={false} isOpen={isCreateOpen} onClose={onCreateClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader mt="8">Create new protocol</ModalHeader>
                    <ModalBody pb={8} align="left">
                        <div style={{margin: '10px 0px'}}>                            
                            <span className="inputlabel bundlewithadd">Bundle: </span>
                            <AddIcon className="bundleadd" onClick={openNewBundle}/>
                            {
                                isOpenNewBundle ? (
                                    <input type="text" className="addprotocol" value={bundleName} onChange={(event) => setBundleName(event.target.value)}/>
                                ) : (bundles.length > 0) && (
                                    <Select
                                        className="addbranch"
                                        options={bundles}
                                        values={selectedBundle ? [selectedBundle] : [bundles[0]]}
                                        onChange={(value) => {
                                            setSelectedBundle(value[0]);
                                        }}
                                        labelField="fields.name"
                                        valueField="id"
                                    />
                                )
                            }
                        </div>
                        <div style={{margin: '10px 0px', display: 'inline-block'}}>
                            <span className="inputlabel">Protocol: </span>
                            <input type="text" className="addprotocol" value={protocolName} onChange={(event) => setProtocolName(event.target.value)}/> 
                        </div>
                        <Box display="flex" float="right" mt="4">
                            <Button colorScheme="gray" onClick={onCreateClose}>Cancel</Button>
                            <Button colorScheme="blue" ml="4" onClick={onClickCreate}>Create</Button>
                        </Box>
                    </ModalBody>
                </ModalContent>
            </Modal>
            <Modal closeOnOverlayClick={false} isOpen={isPreviewOpen} onClose={onPreviewClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader mt="8">Open existing protocol</ModalHeader>
                    <ModalBody pb={8} align="left">
                        
                    </ModalBody>
                </ModalContent>
            </Modal>
        </ThemeProvider>
    )

}

export default Header
