import React, { useEffect, useState, useCallback, CSSProperties, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import Select from 'react-dropdown-select';
import styled from '@emotion/styled';
import { List, AutoSizer, ListProps } from 'react-virtualized';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import BranchList from './BranchList';
import FilterList from './FilterList';
import axios from 'axios'
import { base_url, Filter_Conditions, Filter_Names, Filter_Age_Filters, Filter_Sex_Filters, Filter_PastMedicalHistory_Filters, Filter_LastFollowUp_Filters, pathwayApiOptions } from '../Globals';
import { 
  PropWrapProps, 
  SelectTypes, 
  BranchTypes, 
  BranchData, 
  BranchProps, 
  FilterProps, 
  BundleType, 
  ProtocolType, 
  OptionType
} from '../types';

import { ThemeProvider, CSSReset, Grid, Link, Input, Button, Box, FormControl, Icon,IconButton, InputGroup, Image, Text, Heading } from '@chakra-ui/react'
import { AddIcon } from '@chakra-ui/icons'
import theme from '../styles/theme'

import {
  DbProvider,
  Database,
  Calculator,
  Pathway,
  Drug,
  NoteEditor,
  PathwayThemeProvider,
} from '@pathwaymd/pathway-ui2'

import { View, ViewComponent } from 'react-native';

//import untypedCollectedDb from '../data/collectedPathway.json'
//const collectedDb = (untypedCollectedDb as unknown) as Database;

const PropWrap = (props: PropWrapProps) => {
  const navigate = useNavigate();

  const { 
    dosages, 
    tests, 
    findings, 
    keypoints, 
    diseases, 
    specialties, 
    pathways, 
    calculators, 
  } = props;

  const [selectedOptions, setSelectedOptions] = useState<OptionType[]>([]);
  const [actionType, setActionType] = useState<string>('');
  const [structureType, setStructureType] = useState<string>('');
  const [actions, setActions] = useState<OptionType[]>([]);
  const [branches, setBranches] = useState<BranchProps[]>([]);
  const [filters, setFilters] = useState<FilterProps[]>([]);
  
  const [selectedFilterCondition, setSelectedFilterCondition] = useState<SelectTypes[]>([]);
  const [selectedFilterName, setSelectedFilterName] = useState<SelectTypes[]>([]);
  const [selectedFilterFilter, setSelectedFilterFilter] = useState<SelectTypes[]>([]);
  const [selectedFilterValue, setSelectedFilterValue] = useState<string>('');
  const [selectableFilters, setSelectableFilters] = useState<SelectTypes[]>([]);
  const [selectedBranchPoint, setSelectedBranchPoint] = useState<SelectTypes[]>([]);

  const [collectedDb, setCollectedDb] = useState<Database>();
  
  const [open, setOpen] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [propCard, setPropCard] = useState(props.propData);
  const [inputData, setInputData] = useState('');

  const getDbForCalculator = (calculatorId: string) => {

    const baseUrl = 'http://pathway-api.caprover.do2.pathway.md/v2/calculators/pathway-ui2@1.0.x/'

    axios.get(baseUrl + calculatorId, pathwayApiOptions)
    .then((res: any) => {
      console.log(res)
      setCollectedDb(res.data)
    })
    .catch((err: any) => {
      console.error(err);
    });

  }

  useEffect(() => {
    if (!props.propData) {
      setOpen(false);
      return;
    }
    
    setOpen(props.data);
    setPropCard(props.propData);
    setInputData(props.propData.template);
    setSelectedOptions(props.propData.selectedOptions);
    setSelectedBranchPoint(props.propData.selectedBranchPoint);
    setBranches(props.propData.selectedBranches);
    setFilters(props.propData.selectedFilters);

    if (props.propData.name === 'Repeat timer') {
      setActionType('Repeat timer');
      setStructureType('');
    } else if (props.propData.name === 'Elicit') {
      setActionType('Elicit');
      setStructureType('');
    } else if (props.propData.name === 'Prescribe') {
      setActionType('Prescribe');
      setStructureType('');
    } else if (props.propData.name === 'Order') {
      setActionType('Order');
      setStructureType('');
    } else if (props.propData.name === 'Apply') {
      setActionType('Apply');
      setStructureType('');
    } else if (props.propData.name === 'Link') {
      setActionType('Link');
      setStructureType('');
    } else if (props.propData.name === 'Use') {
      setActionType('Use');
      setStructureType('');
      
      // Change this to be reactive to selected option
      getDbForCalculator('recwxQQCizzPS6xEH')

    } else if (props.propData.name === 'Schedule') {
      setActionType('Schedule');
      setStructureType('');
    } else if (props.propData.name === 'Record') {
      setActionType('Record');
      setStructureType('');
    } else if (props.propData.name === 'Custom') {
      setActionType('Custom');
      setStructureType('');
    } else if (props.propData.name === 'Branch') {
      setStructureType('Branch');
      setActionType('');
    } else if (props.propData.name === 'Include') {
      setStructureType('Include');
      setActionType('');
    } else {
      setActionType('');
      setStructureType('');
      setActions([]); 
    }

    
  }, [props]);

  const customDropdownRenderer = useCallback(({ methods, state, props }) => {
    return (
      <AutoSizer style={{ height: '200px' }}>
        {({width, height}) => {
          return (
            <List
              style={{overflow: 'auto', height: '200px', maxHeight: '200px'}}
              height={height}
              rowCount={actions.length}
              rowHeight={40}
              width={width - 2}
              rowRenderer={({ index, style, key }: { index: number, style: CSSProperties, key: string }) => (
                <Item key={key}
                      style={style}
                      onClick={() => methods.addItem(actions[index])}
                >
                  {actions[index].fields.name}
                </Item>
              )}
            />
          )
        }}
      </AutoSizer>
    );
  }, [actions]);

  const handleClose = () => {
    setOpen(false);
    props.onCloseProperties();
	}

  const openNew = () => {
    setOpenModal(!openModal);
  }

  const deleteBlock = () => {
    props.onDelete();
  }
  
  const onSave = () => {
    const tempIds: string[] = [];
    for (let i = 0; i < selectedOptions.length; i ++) {
      tempIds.push(selectedOptions[i].id);
    }
    props.onSaveBlock(tempIds, actionType);
    props.onSaveCard(selectedOptions, inputData);
  }

  const onCancel = () => {
    setInputData(props.propData.template);
    setSelectedOptions(props.propData.selectedOptions);
  }  

  const handleTextChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputData(event.target.value);
  }

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedFilterValue(event.target.value);
  }

  const onBranchSave = () => {
    const newBranches: BranchProps[] = [...branches];

    let temp = newBranches.length === 0 ? 0 : newBranches[newBranches.length-1].id;
    const tempBranch: BranchProps = {
      id: temp + 1, 
      data: {
        filter: selectedFilterFilter, 
        value: selectedFilterValue, 
      }
    }
    setBranches([...newBranches, tempBranch]);
    setSelectedFilterFilter([]);
    setSelectedFilterValue('');
    setOpenModal(!openModal);
    props.onSaveBranch([...newBranches, tempBranch]);
  }
  
  const deleteBranch = (id: number) => {
    const newBranches = [...branches];
    const resultBranches = newBranches.filter((branch) => branch.id !== id);
    setBranches(resultBranches);
    props.onSaveBranch(resultBranches);
  }

  const onBranchCancel = () => {
    setOpenModal(!openModal);
  }

  const changeFilterName = (value: any) => {
    setSelectedFilterFilter([]);
    if (value && value.length > 0) {
      switch (value[0].type) {
        case 'number': 
          setSelectableFilters(Filter_Age_Filters);
          break;
        case 'string': 
          setSelectableFilters(Filter_Sex_Filters);
          break;
        case 'datetime': 
          setSelectableFilters(Filter_LastFollowUp_Filters);
          break;
        case 'array': 
          setSelectableFilters(Filter_PastMedicalHistory_Filters);
          break;
        default: 
          setSelectableFilters([]);
      }
    }
  }

  const changeBranchPoint = (value: any) => {
    setSelectedFilterFilter([]);
    props.onSaveBranchPoint(value);
  }

  const onFilterSave = () => {
    const newFilters = [...filters];
    if ((newFilters.length !== 0 && selectedFilterCondition.length === 0) || 
        selectedFilterName.length === 0 || 
        selectedFilterFilter.length === 0 || 
        selectedFilterValue === '') {
      return;
    }
    const tempFilter = {
      id: newFilters.length + 1, 
      data: {
        condition: selectedFilterCondition[0] ? selectedFilterCondition : [{id: '1', name: ''}], 
        name: selectedFilterName, 
        filter: selectedFilterFilter, 
        value: selectedFilterValue, 
      }
    }
    setFilters([...newFilters, tempFilter]);
    setSelectedFilterCondition([]);
    setSelectedFilterName([]);
    setSelectedFilterFilter([]);
    setSelectedFilterValue('');
    setOpenModal(!openModal);
    props.onSaveFilter([...newFilters, tempFilter]);
  }

  const deleteFilter = (id: number) => {
    const newFilters = [...filters];
    const resultFilters = newFilters.filter((filter) => filter.id !== id);
    setFilters(resultFilters);
    props.onSaveFilter(resultFilters);
  }

  const onFilterCancel = () => {
    setSelectedFilterCondition([]);
    setSelectedFilterName([]);
    setSelectedFilterFilter([]);
    setSelectedFilterValue('');
    setOpenModal(!openModal);
  }

  return (
    <ThemeProvider theme={theme}>
      <CSSReset/>
      <div id="propwrap" className="itson">
        <div id="properties" className={`${open && 'expanded'}`}>
          <div id="close">
            <IconButton aria-label="delete" size="sm" onClick={handleClose}>
              <img src={`${base_url}/assets/close.svg`} alt="NO"/>
            </IconButton>                    
          </div>
          <p id="header2">Properties</p>
          {
            <>
              <div id="proplist">
                <div style={{margin: 10, marginLeft: 0}}>
                  <span className="inputlabel">Type: </span>
                  {propCard?.name === 'Branch' ? (
                      <span className="inputlabelValue">Filter</span>
                    ) : (
                      <span className="inputlabelValue">{propCard?.name}</span>
                  )}
                 </div>
                <div style={{margin: 10, marginLeft: 0}}>
                  <span className="inputlabel">Description: </span>
                  <span className="inputlabelValue">{propCard?.desc}</span>
                </div>
                {
                  (actionType !== '' && propCard) && (
                    <>
                      <p className="inputlabel">{propCard.templateTitle}</p>
                      {
                        propCard.hasTextInput && (
                          <TextareaAutosize
                            className="inputcomponent"
                            aria-label="minimum height"
                            minRows={3}
                            placeholder="Write custom text here..."
                            value={inputData}
                            onChange={(event) => handleTextChange(event)}
                          />
                        )
                      }
                      {
                        (actionType === 'Prescribe') ?  (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={dosages}
                            multi
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Order') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={tests}
                            multi
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Elicit') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={findings}
                            multi
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Apply') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={keypoints}
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Record') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={diseases}
                            multi
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Schedule') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={specialties}
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Link') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={pathways}
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="fields.name"
                            valueField="id"
                          />
                        ) : (actionType === 'Use') ? (
                          <Select
                            className="addbranch"
                            values={selectedOptions}
                            options={calculators}
                            onChange={(values) => {
                              setSelectedOptions(values);
                            }}
                            labelField="name"
                            valueField="id"
                          />
                        ) : (
                          <></>
                        )
                      }
                      <Box display="flex" float="right" mt="4">
                        <Button colorScheme="gray" onClick={() => onCancel()}>Cancel</Button>
                        <Button colorScheme="blue" ml="4" onClick={() => onSave()}>Save</Button>
                      </Box>
                      { 
                        (actionType === 'Elicit' && selectedOptions && selectedOptions[0]) && (
                          <Box mt="24">
                            <Heading as="h2" size="md">Preview</Heading>
                            <Box className="previewwrapper" mt="4">                                
                              <PathwayThemeProvider>
                                {collectedDb && <DbProvider db={collectedDb}>
                                  <Suspense fallback={null}>
                                    {/* <NoteEditor findingIds={selectedOptions.map((x) => x.id)} onButtonStateChange={() => {}}/> */}
                                  </Suspense>
                              </DbProvider>}
                              </PathwayThemeProvider>
                            </Box>
                          </Box> 
                        )
                      }
                      { 
                        (actionType === 'Use' && selectedOptions && selectedOptions[0]) && (
                          <Box mt="24">
                            <Heading as="h2" size="md">Preview</Heading>
                            <Box className="previewwrapper" mt="4">
                              <PathwayThemeProvider>
                              {collectedDb && <DbProvider db={collectedDb}>
                                  <Suspense fallback={null}>
                                    <Calculator 
                                      calculatorId={'recwxQQCizzPS6xEH'} 
                                      onStateChange={() => {}}/>
                                  </Suspense>
                                </DbProvider>}
                              </PathwayThemeProvider>
                            </Box>
                          </Box> 
                        )
                      }
                    </>
                  )
                }
                {
                  structureType === 'Branch' ? (
                    <>
                      <Box mt="4">
                        <Text className="inputlabel">Select a branch point: </Text>
                        <Select
                          className="addfilterselect"
                          border-radius="6px"
                          options={Filter_Names}
                          values={selectedBranchPoint}
                          onChange={(value) => {
                            setSelectedBranchPoint(value);
                            changeBranchPoint(value);
                            changeFilterName(value);
                          }}
                          labelField="name"
                          valueField="id"
                        />
                      </Box>
                      <Box mt="4">
                      <Text className="inputlabel">Define branches: </Text>                  
                      {
                        branches.length > 0 && (
                          branches.map((branch) => {
                            return (
                              <BranchList key={branch.id} data={branch} deleteBranch={deleteBranch} selectableFilter={selectableFilters}/>
                            )
                          })
                        )
                      }
                      </Box>
                      <Box mt="4">
                        <Button
                          style={{width: '100%'}}
                          colorScheme="blue" 
                          onClick={openNew}>
                          <AddIcon />
                          <Text ml="4">Add a new condition</Text>
                        </Button>
                      </Box>
                      {
                        openModal && (
                          <div className="addmodal">
                            <Box display="flex">
                              <Select
                                style={{width: '175px'}}
                                options={selectableFilters}
                                values={selectedFilterFilter}
                                onChange={(value) => {
                                  setSelectedFilterFilter(value);
                                }}
                                labelField="name"
                                valueField="id"
                              />
                              <input type="text" className="branchinput" onChange={(event) => handleChange(event)}/>                    
                            </Box>
                            <Box display="flex" float="right" mt="4">
                              <Button colorScheme="blue" onClick={() => onBranchCancel()}>Cancel</Button>
                              <Button colorScheme="gray" onClick={() => onBranchSave()}>Save</Button>
                            </Box>
                          </div>
                        )
                      }
                    </>
                  ) : structureType === 'Include' && (
                    <>
                      <p className="inputlabel">Add one or more conditions: </p>
                      {
                        filters.length > 0 && (
                          filters.map((filter) => {
                            return (
                              <FilterList key={filter.id} data={filter} deleteFilter={deleteFilter}/>
                            )
                          })
                        )
                      }
                      <Box mt="4">
                        <Button
                          style={{width: '100%'}}
                          colorScheme="blue" 
                          onClick={openNew}>
                          <AddIcon size="md"/>
                          <Text ml="4">Add a new condition</Text>
                        </Button>
                      </Box>
                      {
                        openModal && (
                          <>
                            <div className="selectgroup">
                              {
                                filters.length === 0 ? (
                                  <span className="addfilterstatic">Where</span>
                                ) : (
                                  <Select
                                    className="addfilterselect"
                                    style={{width: '53px'}}
                                    options={Filter_Conditions}
                                    values={selectedFilterCondition}
                                    onChange={(value) => {
                                      setSelectedFilterCondition(value);
                                    }}
                                    labelField="name"
                                    valueField="id"
                                  />
                                )
                              }
                              <Select
                                className="addfilterselect"
                                style={{width: '112px'}}
                                options={Filter_Names}
                                values={selectedFilterName}
                                onChange={(value) => {
                                  setSelectedFilterName(value);
                                  changeFilterName(value);
                                }}
                                labelField="name"
                                valueField="id"
                              />
                              <Select
                                className="addfilterselect"
                                style={{width: '125px'}}
                                options={selectableFilters}
                                values={selectedFilterFilter}
                                onChange={(value) => {
                                  setSelectedFilterFilter(value);
                                }}
                                labelField="name"
                                valueField="id"
                              />
                              <input type="text" onChange={(event) => handleChange(event)}/>                    
                            </div>
                            <Box display="flex" float="right" mt="4">
                              <Button colorScheme="gray" onClick={() => onFilterCancel()}>Cancel</Button>
                              <Button colorScheme="blue" ml="4" onClick={() => onFilterSave()}>Save</Button>
                            </Box>
                          </>
                        )
                      }
                    </>
                  )
                }
              </div>  
              <Box className="removeblockwrapper">
                <Text className="header2">Delete this block</Text>
                <Box id="removeblock" mt="4">
                  <Button variant="text" onClick={() => deleteBlock()}>Delete block</Button>
                </Box>   
              </Box>
            </>
          }
          
        </div>
      </div>
    </ThemeProvider>
  )
}

export default PropWrap;

const Item = styled.div`
  display: flex;
  padding: 0 10px;
  align-items: center;
  cursor: pointer;
  width: 480px;
  height: 40px;
  display: inline-block;
  white-space: nowrap;
  
  &:hover {
    background: #f2f2f2;
  }  
  `;
  // ${({ disabled }: {disabled: boolean}) => disabled && 'text-decoration: line-through;'}
