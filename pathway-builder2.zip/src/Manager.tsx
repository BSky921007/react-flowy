import React, { useState, useMemo, useContext, useEffect, useRef, Suspense } from 'react'
import { Heading, Button, Box, Text, Grid, VStack, Link, Input, Image, Spacer, Textarea } from '@chakra-ui/react'
import { ThemeProvider, CSSReset, theme } from '@chakra-ui/react'
import { useParams, Link as RouteLink } from 'react-router-dom'
import useLocalstorageState from './client/use-localstorage-state'
import {base_url} from './Globals';
import { PatientType, UserType, NoteType, BundleHistoryType } from './types'

import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  IconButton,
} from "@chakra-ui/react"

import {
  RepeatClockIcon,
  EditIcon,
  LinkIcon,
  SearchIcon,
  TriangleDownIcon,
  PlusSquareIcon
} from '@chakra-ui/icons'

import BareLayout from './BareLayout'
import { Repeat } from '@mui/icons-material'

import axios from 'axios';
import { capitalize } from 'lodash'

const token = 'keymneuuZO7FHj0i3';
const options = {
  headers: {
    'Authorization': `Bearer ${token}`,
  }
};

const customTheme = {
  ...theme,
  fonts: {
    body: 'Inter, system-ui, sans-serif',
    heading: 'Inter, system-ui, sans-serif',
    mono: 'Menlo, monospace',
  },
  colors: {
    ...theme.colors,
    pathway: {
      50: '#e6f2ff',
      100: '#c1d3f3',
      200: '#9bb3e6',
      300: '#7390d9',
      400: '#4c6dcc',
      500: '#335cb3',
      600: '#264f8c',
      700: '#1a3d65',
      800: '#0d2940',
      900: '#02111b',
    },
  },
}

const PageContext = React.createContext({})

const formatAirtableResults = (res: any) => {
  return res.data.records.map((x: any) => {
    return formatAirtableResult({ data: x })
  })
}

const formatAirtableResult = (res: any) => {

  const data = res.data
  const id = data.id
  const fields = data.fields
  let formatted: any = { id }

  const capitalize = (s: string) => {
    if (s.length == 0) return ''
    return s[0].toUpperCase() + (s.length > 1 ? s.slice(1, ) : '')
  }
 
  for (let key in fields) {
    const camelCaseKey = key.split('_').map(
      (x, i) => i ? capitalize(x) : x).join('')
    formatted[camelCaseKey] = fields[key]
  }

  console.log(formatted)
  return formatted

}

const airtableBaseUrl = 'https://api.airtable.com/v0/appJ6LHBEjhaorG0k'

export default function Manager({ patientId } : { patientId?: string  }) {
  
  const userId = 'recaV7dSybHG1netm' // will come from session eventually
  const params = useParams()
  if (params.patientId) patientId = params.patientId

  const [selectedPatientId, setSelectedPatientId] = useState(patientId)
  const [patient, setPatient] = useState<PatientType>(null);
  const [user, setUser] = useState<UserType>(null);
  const [notes, setNotes] = useState<NoteType[]>([]);
  const [bundleHistory, setBundleHistory] = useState<BundleHistoryType[]>([]);
  
  const getPatient = async(patientId: string) => {
    await axios.get(`${airtableBaseUrl}/Patients/${patientId}`, options)
    .then((res: any) => {
      setPatient(formatAirtableResult(res));
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getUser = async(userId: string) => {
    await axios.get(`${airtableBaseUrl}/Users/${userId}`, options)
    .then((res: any) => {
      setUser(formatAirtableResult(res));
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getNotes = async(patientId: string) => {
    await axios.get(encodeURI(`${airtableBaseUrl}/Notes?filterByFormula=SEARCH("${patientId}",{patient})`), options)
    .then((res: any) => {
      setNotes(formatAirtableResults(res));
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getBundleHistory = async(patientId: string) => {
    await axios.get(encodeURI(`${airtableBaseUrl}/History?filterByFormula=SEARCH("${patientId}",{patient})`), options)
    .then((res: any) => {
      setBundleHistory(formatAirtableResults(res));
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  useEffect(() => {
    if (!selectedPatientId) {
      throw new Error('No patient selected.')
    }
    getPatient(selectedPatientId);
    getUser(userId);
    getNotes(selectedPatientId);
    getBundleHistory(selectedPatientId);
  }, []);


  const [autosaved, setAutosaved] = useState(null)
  const [loaded, setLoaded] = useState(false)

  const pageContextValue = useMemo(() => {
    return {
      user,
      patient,
      notes,
      bundleHistory
    }
  }, [user, patient, notes, bundleHistory])

  const { 
    isOpen: isBundleActionsOpen, 
    onOpen: onBundleActionsOpen, 
    onClose: onBundleActionsClose
  } = useDisclosure()

  const { 
    isOpen: isEditPatientOpen, 
    onOpen: onEditPatientOpen, 
    onClose: onEditPatientClose
  } = useDisclosure()

  const { 
    isOpen: isAddNoteOpen, 
    onOpen: onAddNoteOpen, 
    onClose: onAddNoteClose
  } = useDisclosure()
  
  const { 
    isOpen: isSelectPatientOpen, 
    onOpen: onSelectPatientOpen, 
    onClose: onSelectPatientClose
  } = useDisclosure()

  const [selectNewPatientId, setSelectNewPatientId] = useState('')

  const handleChangeSelectNewPatientId = (event: any) => {
    setSelectNewPatientId(event.target.value)
  }

  const onSelectPatientSubmit = () => {
    setSelectedPatientId(selectNewPatientId)
    onSelectPatientClose()
    setTimeout( () => window.location.reload(), 500)
  }
  
  const statusGroups = [
    { name: 'eligible', title: 'Eligible bundles', color: '#d9e7fd'},
    { name: 'inProgress', title: 'In progress', color: '#ffe6cd' },
    { name: 'completed', title: 'Completed', color: '#d4e7d7' },
    { name: 'ineligible', title: 'Ineligible bundles', color: '#f5f5f5' },
  ]

  return <PageContext.Provider value={{ user, patient, notes, bundleHistory, statusGroups }}>
    <BareLayout >
        <ThemeProvider theme={customTheme}>
        <Box pl="16px" pr="16px">
        <CSSReset />
        {patient && user && <Box display="flex" height="76px" pt="16px" pb="16px" borderBottom="1px solid lightgray">
          <Box w="350px" display="flex" align="flex-start">
            <Image src={`${base_url}/assets/logo_small.png`} width="40px" height="37px" mt="2px" alt="Logo"/>
            <Heading as="h1" size="lg" ml="4">Care Manager</Heading>
          </Box>
          <Box id="details" w="350px" display="flex">
            <Box mr="4">
              <Heading as="h3" size="sm">
                {patient.lastName ? `${patient.lastName}, ${patient.firstName}` : ''}
              </Heading>
              <Text>{patient.id}</Text>
            </Box>            

            <Link onClick={onSelectPatientOpen}>
              <IconButton aria-label="" icon={<TriangleDownIcon/>}>
              </IconButton>
            </Link>
              
          </Box>

          <Box position="absolute" right="100">
            <Box display="flex" float="right" mt="2">
              <Box><Text>User:&nbsp;</Text></Box> 
              <Box><Text>{user.name}, {user.title} ({user.licenseNumber})</Text></Box> 
            </Box>
          </Box>
        </Box>}
        <VStack spacing="8" mt="4">
        {patient && notes && <Grid templateColumns="repeat(4, 1fr)" gap={6} width="100%">
          <Box w="100%">
            <Box display="flex" mb="4">
              <Box><Heading as="h2" size="md">Patient Information</Heading></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">First name:&nbsp;</Text></Box> 
              <Box><Text>{patient.firstName}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">Last name:&nbsp;</Text></Box> 
              <Box><Text>{patient.lastName}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">Date of birth:&nbsp;</Text></Box> 
              <Box><Text>{patient.dateOfBirth}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">Sex:&nbsp;</Text></Box> 
              <Box><Text>{patient.sex}</Text></Box> 
            </Box>
          </Box>
          <Box w="100%" >
            <Box display="flex" mt="10">
              <Box><Text fontWeight="bold">Pronouns:&nbsp;</Text></Box> 
              <Box><Text>{patient.pronouns}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">Phone:&nbsp;</Text></Box> 
              <Box><Text>{patient.phoneNumber}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">Address:&nbsp;</Text></Box> 
              <Box><Text>{patient.address}</Text></Box> 
            </Box>
            <Box display="flex">
              <Box><Text fontWeight="bold">City:&nbsp;</Text></Box> 
              <Box><Text>{patient.city}</Text></Box> 
            </Box>
          </Box>
          <Box w="100%" >
            <Box display="flex" mb="4">
              <Box><Heading as="h2" size="md">Notes</Heading></Box> 
            </Box>
            {notes.length == 0 ? (<Text>No notes yet.</Text>) :
            notes.map((note: any) => {
              return <>
                <Text fontWeight="bold">{note.date}</Text>
                <Box display="flex"><Text>{note.title}</Text>
                  <Link href={note.pdf[0].url} target="_blank">
                    <LinkIcon mt="1" ml="1" color="#4c6dcc" />
                  </Link>
                </Box> 
              </>
            })}
          </Box>
          <Box w="100%" >
            <Box display="flex" mb="4">
              <Box><Heading as="h2" size="md">Actions</Heading></Box> 
            </Box>
            <Box>
              <Link onClick={onEditPatientOpen}>
              <Button borderRadius="5" width="100%" height="10" leftIcon={<EditIcon/>}>
                <Text>Edit patient information</Text>
              </Button>
              </Link>
            </Box> 
            <Box mt="4">
              <Link onClick={onAddNoteOpen}>
              <Button borderRadius="5" width="100%" height="10" leftIcon={<PlusSquareIcon/>}>
                <Text>Create a new note</Text>
              </Button>
              </Link>
            </Box> 
          </Box>
          </Grid>}
          {bundleHistory && <Grid templateColumns="repeat(4, 1fr)" gap={6} width="100%">
            {
              statusGroups.map((group) => {
                return <Box w="100%" h="10">
                  <Box>
                    <Box><Heading as="h2" size="md">{group.title}</Heading></Box> 
                  </Box>
                  <Box mt="4" mb="4">
                    {bundleHistory.filter((b: any) => b.status == group.name).map((bundle) => {
                      if (!bundle) return <></>
                      return <Box h="40" p="4" mb="4" borderRadius="5" border="1px solid #4c6dcc;">                        
                        <Link onClick={onBundleActionsOpen}>
                        <Box mb="4"><Heading as="h3" size="sm" color="#4c6dcc">{bundle.name}</Heading></Box>
                        </Link>
                        <Box>
                          <Text fontSize="14px">
                          {bundle.status == 'completed' ? `Completed on ${bundle.completedDate}. ` : ''}
                          {bundle.status == 'inProgress' ? `Started on ${bundle.startedDate}. ` : ''}
                          {bundle.status == 'eligible' ? `Never completed. Eligible since ${bundle.eligibleDate}. ` : ''}
                          {bundle.status == 'ineligible' ? `Not eligible. ` : ''}
                          {bundle.status == 'completed' ? (bundle.expires ? `Expires ${bundle.expiresDate}. ` : 'Never expires.' ) : ''}
                          </Text>
                        </Box>                        
                      </Box> 
                    })}
                  </Box>
                  <Text></Text>
                </Box>
              })
            }
            </Grid>}
          <Modal closeOnOverlayClick={false} isOpen={isBundleActionsOpen} onClose={onBundleActionsClose}>
            <ModalOverlay />
            <ModalContent>
              <ModalHeader mt="8">What would you like to do with this bundle?</ModalHeader>
              <ModalCloseButton />
              <ModalBody pb={8} align="center">
                <Box>
                  <RouteLink to={`/patients/${patientId}/bundles/recfTPwyzRqM3dk0I`}>
                    <Link>
                      <Button colorScheme="blue" mt={4} w={200} leftIcon={<EditIcon />}>
                        Work on it now
                      </Button>
                    </Link>
                  </RouteLink>
                </Box>
                <Box>
                  <Button colorScheme="orange" mt={4} w={200} leftIcon={<RepeatClockIcon />}>
                    Schedule for later
                  </Button>
                </Box>
              </ModalBody>
            </ModalContent>
          </Modal>
          <Modal closeOnOverlayClick={false} isOpen={isEditPatientOpen} onClose={onEditPatientClose}>
            <ModalOverlay />
            <ModalContent>
              <ModalHeader mt="8">Edit this patient's information</ModalHeader>
              <ModalCloseButton />
              <ModalBody pb={8} align="center">
                <Box>
                    <Button colorScheme="blue" mt={4} w={200} leftIcon={<EditIcon />}>
                        Save
                      </Button>
                </Box>
              </ModalBody>
            </ModalContent>
          </Modal>
          <Modal closeOnOverlayClick={false} isOpen={isAddNoteOpen} onClose={onAddNoteClose}>
            <ModalOverlay />
            <ModalContent>
              <ModalHeader mt="8">Add a note</ModalHeader>
              <ModalCloseButton />
              <ModalBody pb={8} align="center">
                <Textarea />
                <Box>
                  <Button colorScheme="blue" mt={4} w={200} leftIcon={<EditIcon />} onClick={onAddNoteClose}>
                    Save
                  </Button>
                </Box>
              </ModalBody>
            </ModalContent>
          </Modal>
          <Modal closeOnOverlayClick={false} isOpen={isSelectPatientOpen} onClose={onSelectPatientClose}>
            <ModalOverlay />
            <ModalContent>
              <ModalHeader mt="8">Enter a patient identifier: </ModalHeader>
              <ModalCloseButton />
              <ModalBody pb={8} align="center">
                <Box>
                  <Input value={selectNewPatientId} onChange={handleChangeSelectNewPatientId} />
                  <RouteLink to={`/patients/${selectNewPatientId}`}>
                    <Link>
                      <Button colorScheme="blue" mt={4} w={200} leftIcon={<SearchIcon />} onClick={onSelectPatientSubmit}>
                        Lookup patient
                      </Button>
                    </Link>
                  </RouteLink>
                </Box>
              </ModalBody>
            </ModalContent>
          </Modal>
          <Box position="absolute" bottom="75px" right="16px" width="266px" height="10px">
            <RouteLink to="/builder/recfTPwyzRqM3dk0I">
              <Link>
                <Button colorScheme="green" size="md" width="100%">
                  <Text>Open Protocol Editor</Text>
                </Button>
              </Link>
            </RouteLink>
          </Box>
          </VStack>
        </Box>
      </ThemeProvider>
    </BareLayout>
  </PageContext.Provider>

}