import React, { useCallback, useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './builder.css';
import './flowy.css';
import Header from './components/Header';
import LeftTab from './components/LeftTab';
import Canvas from './components/Canvas';
import PropWrap from './components/PropWrap';
import { 
  BranchProps, 
  FilterProps, 
  CardData, 
  SelectTypes, 
  BranchTypes, 
  GlobalData, 
  BundleType, 
  ProtocolType, 
  BlockData, 
  OptionType, 
} from './types';
import { arrayToString, options } from './Globals';
import { pathwayApiOptions } from './Globals';
import BareLayout from './BareLayout'

import { Box } from '@chakra-ui/react'

export const Builder = () => {
  const navigate = useNavigate();
  const { protocolId } = useParams();
  const [dosage_names, setDosage_Names] = useState<OptionType[]>([]);
  const [test_names, setTest_Names] = useState<OptionType[]>([]);
  const [finding_names, setFinding_Names] = useState<OptionType[]>([]);
  const [keypoint_names, setKeypoint_Names] = useState<OptionType[]>([]);
  const [disease_names, setDisease_Names] = useState<OptionType[]>([]);
  const [specialty_names, setSpecialty_Names] = useState<OptionType[]>([]);
  const [pathway_names, setPathway_Names] = useState<OptionType[]>([]);
  const [calculator_names, setCalculator_Names] = useState<OptionType[]>([]);
  const [isOpenProp, setIsOpenProp] = useState(false);
  const [bundles, setBundles] = useState<BundleType[]>([]);
  const [protocols, setProtocols] = useState<ProtocolType[]>([]);
  const [selectedBundle, setSelectedBundle] = useState<BundleType>();
  const [selectedProtocol, setSelectedProtocol] = useState<ProtocolType>();
  const [selectableProtocols, setSelectableProtocols] = useState<ProtocolType[]>([]);

  const [rightCards, setRightCards] = useState<CardData[]>([]);
  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [index, setIndex] = useState(0);

  const getElements = useCallback((elementId: number, elements: CardData[]): number[] => {
    const tempCard = elements.find(({ id }) => id === elementId);
    const childrenIds = tempCard?.childrenIds;
    if (!childrenIds || childrenIds?.length === 0) {
      return [elementId];
    }
    let result: number[] = [];
    for (let i = 0; i < childrenIds!.length; i++) {
      const child = childrenIds[i];
      const childElements = getElements(child, elements);
      if (result.find((temp) => temp === elementId)) result = [...result, ...childElements];
      else result = [...result, elementId, ...childElements];
    }
    if (result.length > 0) return result;
    else return [];
  }, []);

  const getBlockIds = useCallback((elementId: string, elements: BlockData[]): string[] => {
    const tempBlock = elements.find(({ id }) => id === elementId);
    if (tempBlock) {
      const edgeIds = tempBlock.fields.edges;
      if (!edgeIds || edgeIds.length === 0) {
        return [elementId];
      }
      let result: string[] = [];
      for (let i = 0; i < edgeIds.length; i ++) {
        const child = edgeIds[i];
        const childElements = getBlockIds(child, elements);
        if (result.find((temp) => temp === elementId)) result = [...result, ...childElements];
        else result = [...result, elementId, ...childElements];
      }
      if (result.length > 0) return result;
      else return [];
    } else return [];
  }, []);

  const saveCards = (cards: CardData[]) => {
    setRightCards(cards);
  }

  const saveBlocks = (blocks: BlockData[]) => {
    setBlocks(blocks);
  }

  const onViewProps = (propCards: CardData[], id: number) => {
    let flag = false;
    setRightCards(propCards);
    for (var i = 0; i < propCards.length; i ++) {
      if (propCards[i].isOpenProps === true) {
        flag = true;
        setIndex(i);
        break;
      }
    } 
    setIsOpenProp(flag);
  }

  const deleteCardFromCanvas = (action: CardData[]) => {
    if (action) {
      setRightCards(action);
    }
  }

  const deleteCard = () => {
    if (index === 0) {
      setRightCards([]);
      setBlocks([]);
    } else if (index > 0) {
      const newCards = [...rightCards];
      const id = newCards[index].id;
      const tempSelectedIds = getElements(id, newCards);
      const tempSelCard = newCards.find((newCard) => newCard.id === id);
      if (tempSelCard) {
        const tempParentCard = newCards.find((newCard) => newCard.id === tempSelCard.parentId);
        if(tempParentCard) {
          tempParentCard.childrenIds = tempParentCard.childrenIds.filter((b) => b !== id);
          tempParentCard.childrenCnt --;
        }
        setRightCards(newCards.filter((newCard) => !tempSelectedIds.includes(newCard.id)));
      }

      const newBlocks = [...blocks];
      const savedId = newBlocks[index].id;
      const tempParentBlock = newBlocks.find(({ id }) => id === newCards[index].parentSavedId);
      if (tempParentBlock) {
        tempParentBlock.fields.edges = tempParentBlock.fields.edges.filter((b) => b !== savedId);
      }
      const tempSelectedBlockIds = getBlockIds(savedId, newBlocks);
      const tempNonSelectedBlocks = newBlocks.filter(({ id }) => !tempSelectedBlockIds.includes(id));
      for (let i = 0; i < tempSelectedBlockIds.length; i ++) {
        axios.delete(`https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Blocks/${tempSelectedBlockIds[i]}`, options)
        .then((res: any) => {
          console.log(res.data);
        })
        .catch((err: any) => {
          console.log(err);
        })
      }
      setBlocks(tempNonSelectedBlocks);
    }
  }

  const updateBlock = async(element: BlockData) => {
    const data = {
      fields: {
        block_type: element.fields.block_type, 
        edges: element.fields.edges ? element.fields.edges : [], 
        protocol: element.fields.protocol, 
        dosages: element.fields.dosages ? element.fields.dosages : [], 
        tests: element.fields.tests ? element.fields.tests : [], 
        findings: element.fields.findings ? element.fields.findings : [], 
        keypoints: element.fields.keypoints ? element.fields.keypoints : [], 
        diseases: element.fields.diseases ? element.fields.diseases : [], 
        specialties: element.fields.specialties ? element.fields.specialties : [], 
        pathways: element.fields.pathways ? element.fields.pathways : [], 
        calculators: element.fields.calculators ? element.fields.calculators : []
      }
    };
    console.log(data);
    await axios.patch(`https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Blocks/${element.id}`, data, options)
    .then((res: any) => {
      console.log(res.data);
      const newBlocks = [...blocks];
      const updatedBlock = newBlocks.find(({ id }) => id === element.id);
      if (updatedBlock) {
        updatedBlock.id = res.data.id;
        updatedBlock.fields = res.data.fields;
        updatedBlock.createdTime = res.data.createdTime;
        setBlocks(newBlocks);
      }
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const saveCard = (action: OptionType[], input: string) => {
    if (index > -1) {
      const newCards = [...rightCards];
      const selectedCard = newCards[index];
      if (selectedCard.name === 'Custom') {
        selectedCard.template = input;
        selectedCard.selectedOptions = action;
      } else {
        selectedCard.template = arrayToString(action);
        selectedCard.selectedOptions = action;
      }
      setRightCards(newCards);
    }
  }

  const saveBlock = (actionIds: string[], type: string) => {
    console.log(actionIds);
    const newBlocks = [...blocks];
    const selectedBlock = newBlocks[index];
    if (type === 'Prescribe') {
      selectedBlock.fields.dosages = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Order') {
      selectedBlock.fields.tests = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Elicit') {
      selectedBlock.fields.findings = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Apply') {
      selectedBlock.fields.keypoints = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Record') {
      selectedBlock.fields.diseases = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Schedule') {
      selectedBlock.fields.specialties = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Link') {
      selectedBlock.fields.pathways = actionIds;
      updateBlock(selectedBlock);
    } else if (type === 'Use') {
      selectedBlock.fields.calculators = actionIds;
      updateBlock(selectedBlock);
    }
  }

  const saveBranch = (action: BranchProps[]) => {
    if (index > -1) {
      const newCards = [...rightCards];
      const selectedCard = newCards[index];
      selectedCard.selectedBranches = action;
      setRightCards(newCards);
    }
  }

  const saveFilter = (action: FilterProps[]) => {
    if (index > -1) {
      const newCards = [...rightCards];
      const selectedCard = newCards[index];
      selectedCard.selectedFilters = action;
      selectedCard.template = '';
      for (let i = 0; i < action.length; i ++) {
        selectedCard.template += `${action[i].data.condition[0].name} ${action[i].data.name[0].name} ${action[i].data.filter[0].name} ${action[i].data.value} `;
        selectedCard.template = selectedCard.template.replace("...", "");
      }
      setRightCards(newCards);
    }
  }

  const saveFilterName = (action: any) => {
  }

  const saveBranchPoint = (action: BranchTypes[]) => {
    if (action.length > 0) {
      const newCards = [...rightCards];
      const selectedCard = newCards[index];
      selectedCard.selectedBranchPoint = action;
      selectedCard.begin = 'Branch on ';
      selectedCard.template = action[0].name;
      setRightCards(newCards);
    }
  }

  const loadFromJson = (action: GlobalData) => {
    if (action) {
      setRightCards(action.blocks);
      setSelectedBundle(action.properties.bundle);
      setSelectedProtocol(action.properties.protocol);
    }
  }

  // const viewGlobal = () => {
  //   const newCards = [...rightCards];
  //   for (let i = 0; i < newCards.length; i ++) {
  //     newCards[i].isOpenProps = false;
  //   }
  //   setRightCards(newCards);
  //   if (!isOpenGlobal) {
  //     setIsOpenProp(false);
  //     setIsOpenHeader(false);
  //   }
  //   setIsOpenGlobal(!isOpenGlobal);
  // } 

  // const viewHeader = () => {
  //   const newCards = [...rightCards];
  //   for (let i = 0; i < newCards.length; i ++) {
  //     newCards[i].isOpenProps = false;
  //   }
  //   setRightCards(newCards);
  //   if (!isOpenHeader) {
  //     setIsOpenProp(false);
  //     setIsOpenGlobal(false);
  //   }
  //   setIsOpenHeader(!isOpenHeader);
  // }

  const getBundles = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Bundles', options)
    .then((res: any) => {
      setBundles(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getProtocols = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Protocols', options)
    .then((res: any) => {
      setProtocols(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getDosages = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Dosages', options)
    .then((res: any) => {
      setDosage_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getTests = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Tests', options)
    .then((res: any) => {
      setTest_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getFindings = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Findings', options)
    .then((res: any) => {
      setFinding_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getKeypoints = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Keypoints', options)
    .then((res: any) => {
      setKeypoint_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getDiseases = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Diseases', options)
    .then((res: any) => {
      setDisease_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getSpecialties = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Specialties', options)
    .then((res: any) => {
      setSpecialty_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getPathways = async() => {
    await axios.get('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Pathways', options)
    .then((res: any) => {
      setPathway_Names(res.data.records);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const getCalculators = async() => {
    await axios.get('http://pathway-api.caprover.do2.pathway.md/v2/calculators', pathwayApiOptions)
    .then((res: any) => {
      setCalculator_Names(res.data);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const patchProtocol = async(tempProtocol: ProtocolType) => {
    const data = {
      records: [
        {
          fields: {
            name: tempProtocol.fields.name, 
            bundles: tempProtocol.fields.bundles
          }, 
          id: tempProtocol.id
        }
      ]
    };

    await axios.patch('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Protocols', data, options)
    .then((res: any) => {
      const tempProtocols = [...protocols];
      const temp = tempProtocols.find(({ id }) => id === res.data.records[0].id);
      if (temp) {
        temp.createdTime = res.data.records[0].createdTime;
        temp.id = res.data.records[0].id;
        temp.fields = res.data.records[0].fields;
        temp.fields.id = res.data.records[0].id;
        setSelectedProtocol(temp);
      }
      setProtocols(tempProtocols);
    })
    .catch((err: any) => {
      console.log(err);
    });
  }

  const headerOpenSave = (tempBundle: BundleType, tempProtocol: ProtocolType) => {
    setSelectedBundle(tempBundle);
    setSelectedProtocol(tempProtocol);
  }

  const headerEditSave = async(tempBundle: BundleType, tempProtocol: ProtocolType) => {
    if (!tempBundle.fields.protocols) {
      tempBundle.fields = {...tempBundle.fields, protocols: []};
    }
    tempBundle.fields.protocols.push(tempProtocol.id);
    const data = {
      records: [
        {
          fields: {
            name: tempBundle.fields.name, 
            protocols: tempBundle.fields.protocols
          }, 
          id: tempBundle.id
        }
      ]        
    };
    await axios.patch('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Bundles', data, options)
    .then((res) => {
      const newBundles = [...bundles];
      const tmpBundle = newBundles.find(({ id }) => id === tempBundle.id);
      if (tmpBundle) {
        if (!tmpBundle.fields.protocols) {
          tmpBundle.fields = {...tmpBundle.fields, protocols: []};
        }
        tmpBundle.fields.protocols = res.data.records[0].fields.protocols;
        setBundles(newBundles);
        setSelectedBundle(tmpBundle);
      }

      const newProtocols = [...protocols];
      const tmpProtocol = newProtocols.find(({ id }) => id === tempProtocol.id);
      if (tmpProtocol) {
        if (!tmpProtocol.fields.bundles) {
          tmpProtocol.fields = {...tmpProtocol.fields, bundles: []};
        }
        tmpProtocol.fields.bundles.push(tempBundle.id);
        setProtocols(newProtocols);
        setSelectedProtocol(tmpProtocol);
      }
    })
    .catch((err) => {
      console.log(err);
    })
  }

  const headerCreateSave = async(actionBundle: BundleType, actionBundleName: string, actionProtocolName: string, actionFlag: boolean) => {
    if (actionFlag) {
      const bundleData = {
        records: [
          {
            fields: {
              name: actionBundleName
            }
          }
        ]
      };
      await axios.post('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Bundles', bundleData, options)
      .then((res) => {
        addNewProtocol(actionProtocolName, res.data.records[0]);
      })
      .catch((err) => {
        console.log(err);
      })
    } else {
      addNewProtocol(actionProtocolName, actionBundle);
    }
  }

  const addNewProtocol = async(actionProtocolName: string, actionBundle: BundleType) => {
    const protocolData = {
      records: [
        {
          fields: {
            name: actionProtocolName, 
            bundles: [actionBundle.id]
          }
        }
      ]
    }
    await axios.post('https://api.airtable.com/v0/appJ6LHBEjhaorG0k/Protocols', protocolData, options)
    .then((res) => {
      const targetUrl = `/builder/${res.data.records[0].id}`;
      navigate(targetUrl);
      setSelectedBundle(actionBundle);
      getProtocols();
      getBundles();
    })
    .catch((err) => {
      console.log(err)
    });
  }

  const closeProperties = () => {
    setIsOpenProp(false);
  }

  useEffect(() => {
    getBundles();
    getProtocols();
    getDosages();
    getTests();
    getFindings();
    getKeypoints();
    getDiseases();
    getSpecialties();
    getPathways();
    getCalculators();
  }, []);

  useEffect(() => {
    const tempProtocol = protocols.find(({ id }) => id === protocolId);
    if (tempProtocol) {
      setSelectedProtocol(tempProtocol);

      if (selectedBundle) return;

      const tempBundle = bundles.find(({ id }) => id === tempProtocol.fields.bundles[0]);
      if (tempBundle) {
        setSelectedBundle(tempBundle);
      }
    }
  }, [protocols, bundles, protocolId, selectedBundle]);

  useEffect(() => {
    if (selectedBundle && protocols.length > 0) {
      const tempProtocols: ProtocolType[] = [];
      for (let i = 0; i < protocols.length; i ++) {
        if (protocols[i].fields.bundles.includes(selectedBundle.id)) {
          tempProtocols.push(protocols[i]);
        }
      }
      setSelectableProtocols(tempProtocols); 
    }
  }, [selectedBundle, protocols]); 

  return (
    <Box className="App">
      <BareLayout>
      <Box>
      <Box pl="16px" pr="16px">
        <Header 
          data={rightCards} 
          bundles={bundles}
          protocols={protocols}
          selBundle={selectedBundle}
          selProtocol={selectedProtocol}
          onLoad={loadFromJson} 
          onOpenSave={headerOpenSave}
          onEditSave={headerEditSave}
          onCreateSave={headerCreateSave}
        />
      </Box>
      <LeftTab />
      <PropWrap 
        data={isOpenProp} 
        dosages={dosage_names}
        tests={test_names}
        findings={finding_names}
        keypoints={keypoint_names}
        diseases={disease_names}
        specialties={specialty_names}
        pathways={pathway_names}
        calculators={calculator_names}
        propData={rightCards[index]} 
        onDelete={deleteCard} 
        onSaveCard={saveCard} 
        onSaveBranch={saveBranch} 
        onSaveFilter={saveFilter}
        onSaveFilterName={saveFilterName}
        onSaveBranchPoint={saveBranchPoint}
        onSaveBlock={saveBlock}
        onCloseProperties={closeProperties}
      />
      <Canvas 
        isOpenProp={isOpenProp} 
        cardsData={rightCards} 
        blocksData={blocks}
        selBundle={selectedBundle}
        selProtocol={selectedProtocol}
        onPropsView={onViewProps} 
        onSaveCards={saveCards}
        onSaveBlocks={saveBlocks}
        onDeleteCard={deleteCardFromCanvas}
      />
      </Box>
      </BareLayout>
    </Box>
  );
}

export default Builder;
